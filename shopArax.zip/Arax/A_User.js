//const Shopping_cart = require("./A_shop_c.js");
//const Product = require("./A_prod.js");

module.exports = class User{

        constructor(shopping_cart){
        	this.shopping_cart = shopping_cart;

	}
}
/*
let book = new Product("Datastanadirk", "458", "red");
let book1 = new Product("Datastanadirk", "458", "red");

let shop = new Shopping_cart();
shop.add_product(book);
shop.add_product(book1);

let user = new User(shop);
console.log(user.shopping_cart);
*/
