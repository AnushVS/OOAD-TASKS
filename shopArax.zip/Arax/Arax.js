const Shopping_cart = require("./A_shop_c.js");
const Product = require("./A_product.js");
const User = require("./A_User.js");

let book1 = new Product("Datastanagirk", "15000 dram", "M. Gosh");
let book2 = new Product("Aghvesagirk", "10000 dram", "V. Aygektsi");
let shop = new Shopping_cart();

shop.add_product(book1);
shop.add_product(book2);
shop.remove_product(book1);

let user = new User(shop);

