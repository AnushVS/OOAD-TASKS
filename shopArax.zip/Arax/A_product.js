module.exports = class Product{
	constructor(name, price, author){
        	this.name = name;
        	this.price = price;
       		this.author = author;
        
        }
}


