module.exports = class Shopping_cart{
        
	constructor(){
        
		this.products = [];
        }

        add_product(product){
        	
		return this.products.push(product);
	}
	
	remove_product(removed_product)
	
	{
		return this.products.filter(product => product != removed_product);
	}
	

}

